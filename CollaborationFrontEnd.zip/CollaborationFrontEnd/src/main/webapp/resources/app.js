/**
 * 
 */
var mainApp = angular.module("mainApp", ['ngRoute']);

mainApp.config(function($routeProvider) {
	$routeProvider
	
		.when('/home', {
			templateUrl: 'home.html',
			controller: 'StudentController'
		})
		.when('/register', {
			templateUrl: 'user/register.html',
			controller: 'UserController as ctrl'
		})
		.when('/login', {
			templateUrl: 'user/login.html',
			controller: 'UserController as ctrl'
		})
		.when('/create_blog', {
			templateUrl: 'blog/create_blog.html',
			controller: 'BlogController as ctrl'
		})
		.when('/list_blog', {
			templateUrl: 'blog/list_blog.html',
			controller: 'BlogController as ctrl'
		})
		.when('/view_blog', {
			templateUrl: 'blog/view_blog.html',
			controller: 'BlogController as ctrl'
		})
		.when('/new_request_list', {
			templateUrl: 'friend/new_request_list.html',
			controller: 'FriendController as ctrl'
		})
		.when('/search_friend', {
			templateUrl: 'friend/search_friend.html',
			controller: 'FriendController as ctrl'
		})
		.when('/view_friend', {
			templateUrl: 'friend/view_friend.html',
			controller: 'FriendController as ctrl'
		})
		.when('/post_job', {
			templateUrl: 'job/post_job.html',
			controller: 'JobController as ctrl'
		})
		.when('/search_job', {
			templateUrl: 'job/search_job.html',
			controller: 'JobController as ctrl'
		})
		.when('/view_applied_job', {
			templateUrl: 'job/view_applied_job.html',
			controller: 'JobController as ctrl'
		})
		.when('/view_job_details', {
			templateUrl: 'job/view_job_details.html',
			controller: 'JobController as ctrl'
		})
		.when('/list_events', {
			templateUrl: 'event/list_events.html',
			controller: 'EventController as ctrl'
		})
		.when('/view_event', {
			templateUrl: 'event/view_event.html',
			controller: 'EventController as ctrl'
		})
		.when('/create_event', {
			templateUrl: 'event/create_event.html',
			controller: 'EventController as ctrl'
		})
		.when('/create_forum', {
			templateUrl: 'forum/create_forum.html',
			controller: 'ForumController as ctrl'
		})
		.when('/list_forums', {
			templateUrl: 'forum/list_forums.html',
			controller: 'ForumController as ctrl'
		})
		.when('/view_forum', {
			templateUrl: 'forum/view_forum.html',
			controller: 'ForumController as ctrl'
		})
		.when('/abc', {
			templateUrl: 'abc.html',
			controller: 'StudentController'
		})
		.otherwise({
			redirectTo: '/home'
		});
	
	
	
	
});








