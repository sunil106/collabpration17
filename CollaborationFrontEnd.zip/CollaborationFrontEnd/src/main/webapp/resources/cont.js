/**
 * 
 */
mainApp.controller('StudentController', function($scope,$window,$location,$route) {
	$scope.students = [
		{name: 'Mark Waugh', city:'New York'},
		{name: 'Steve Jonathan', city:'London'},
		{name: 'John Marcus', city:'Paris'}
	];

	$scope.message = "Click on the hyper link to view the students list.";
	
	$scope.logout=function()
	{
		/*var currentPageTemplate = $route.current.templateUrl;
		$templateCache.remove(currentPageTemplate);
		$route.reload();*/
		alert('hhah');
		$location.path('/abc').replace();
		//$window.location.href="#/abc";
		/*$window.location.reload();
*/	}
	
});